from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import joblib
from pydantic import BaseModel

app = FastAPI()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load model
model = joblib.load('isro_failure_model.joblib')

class PredictionInput(BaseModel):
    component_type: str
    pressure_test_result: float
    temperature_test_result: float
    vibration_test_result: float
    electrical_test_result: float
    cycles_completed: int
    time_under_load: int

@app.post("/predict")
async def predict(input_data: PredictionInput):
    # Convert input to dataframe
    input_dict = input_data.dict()
    df = pd.DataFrame([input_dict])
    
    # Preprocess
    df = pd.get_dummies(df)
    
    # Ensure all expected columns are present
    expected_columns = set(model.feature_names_in_)
    for col in expected_columns:
        if col not in df.columns:
            df[col] = 0
    
    # Reorder columns to match training
    df = df[model.feature_names_in_]
    
    # Predict
    prediction = model.predict(df)
    probability = model.predict_proba(df)[:, 1]
    
    return {
        "prediction": int(prediction[0]),
        "probability": float(probability[0]),
        "component": input_data.component_type
    }

@app.post("/predict_batch")
async def predict_batch(file: UploadFile = File(...)):
    # Read uploaded file
    df = pd.read_csv(file.file)
    
    # Store original data for output
    original_df = df.copy()
    
    # Preprocess
    if 'test_id' in df.columns:
        df = df.drop('test_id', axis=1)
    if 'failure_occurred' in df.columns:
        df = df.drop('failure_occurred', axis=1)
    
    df = pd.get_dummies(df)
    
    # Ensure all expected columns are present
    expected_columns = set(model.feature_names_in_)
    for col in expected_columns:
        if col not in df.columns:
            df[col] = 0
    
    # Reorder columns to match training
    df = df[model.feature_names_in_]
    
    # Predict
    predictions = model.predict(df)
    probabilities = model.predict_proba(df)[:, 1]
    
    # Add predictions to original data
    original_df['predicted_failure'] = predictions
    original_df['failure_probability'] = probabilities
    
    return original_df.to_dict(orient='records')