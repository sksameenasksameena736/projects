import streamlit as st
import pandas as pd
import requests
import json
from io import StringIO

# App title
st.title("ISRO Rocket Component Failure Predictor")
st.markdown("""
This tool predicts potential failures in ISRO rocket components before launch using historical test data.
""")

# API endpoint
API_URL = "http://localhost:8000"

# Sidebar
st.sidebar.header("About")
st.sidebar.info("""
This project aims to reduce test-to-launch failure risks by predicting 
subsystem failures using machine learning on historical test data.
""")

# Main interface
tab1, tab2 = st.tabs(["Single Prediction", "Batch Prediction"])

with tab1:
    st.header("Single Component Prediction")
    
    with st.form("single_pred_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            component_type = st.selectbox(
                "Component Type",
                ["Fuel Valve", "Oxidizer Pump", "Turbine", "Nozzle", "Actuator", "Sensor"]
            )
            pressure_test = st.number_input("Pressure Test Result (%)", 0, 100, 95)
            temp_test = st.number_input("Temperature Test Result (°C)", 0, 200, 120)
            
        with col2:
            vibration_test = st.number_input("Vibration Test Result (g)", 0.0, 10.0, 4.5)
            electrical_test = st.number_input("Electrical Test Result (%)", 0, 100, 98)
            cycles = st.number_input("Cycles Completed", 0, 1000, 150)
            time_load = st.number_input("Time Under Load (minutes)", 0, 500, 45)
        
        submitted = st.form_submit_button("Predict Failure Probability")
        
        if submitted:
            input_data = {
                "component_type": component_type,
                "pressure_test_result": pressure_test,
                "temperature_test_result": temp_test,
                "vibration_test_result": vibration_test,
                "electrical_test_result": electrical_test,
                "cycles_completed": cycles,
                "time_under_load": time_load
            }
            
            try:
                response = requests.post(f"{API_URL}/predict", json=input_data)
                result = response.json()
                
                if result['prediction'] == 1:
                    st.error(f"⚠️ Failure predicted for {result['component']}!")
                    st.error(f"Probability of failure: {result['probability']*100:.2f}%")
                    st.warning("Recommendation: Inspect and replace this component before launch.")
                else:
                    st.success(f"✅ No failure predicted for {result['component']}")
                    st.info(f"Probability of failure: {result['probability']*100:.2f}%")
                
            except Exception as e:
                st.error(f"Error making prediction: {str(e)}")

with tab2:
    st.header("Batch Prediction from CSV")
    
    uploaded_file = st.file_uploader("Upload test data CSV", type=["csv"])
    
    if uploaded_file is not None:
        try:
            # Display preview
            df = pd.read_csv(uploaded_file)
            st.write("Data Preview:")
            st.dataframe(df.head())
            
            if st.button("Predict for All Components"):
                # Reset file pointer
                uploaded_file.seek(0)
                
                # Make API request
                files = {"file": uploaded_file}
                response = requests.post(f"{API_URL}/predict_batch", files=files)
                
                if response.status_code == 200:
                    results = pd.DataFrame(response.json())
                    
                    st.success("Predictions completed!")
                    st.dataframe(results)
                    
                    # Show summary
                    failure_count = results['predicted_failure'].sum()
                    st.subheader(f"Summary: {failure_count} components predicted to fail")
                    
                    # Download button
                    csv = results.to_csv(index=False)
                    st.download_button(
                        "Download Predictions",
                        data=csv,
                        file_name="isro_failure_predictions.csv",
                        mime="text/csv"
                    )
                else:
                    st.error(f"Error in prediction: {response.text}")
                    
        except Exception as e:
            st.error(f"Error processing file: {str(e)}")

# Sample data download
st.sidebar.header("Sample Data")
st.sidebar.download_button(
    "Download Sample CSV",
    data=open("sample_data.csv", "rb").read(),
    file_name="sample_isro_test_data.csv",
    mime="text/csv"
)