import streamlit as st
from pages.upload_predict import upload_and_predict
from pages.map_view import map_view
from pages.summary import show_summary
from auth.login import login_user

st.set_page_config(page_title="Smart Waste Management System", layout="wide")

st.sidebar.title("Navigation")
page = st.sidebar.selectbox("Choose a page:", [
    "Login",
    "Upload & Predict",
    "Map View",
    "AI Summary"
])

if page == "Login":
    login_user()
elif page == "Upload & Predict":
    upload_and_predict()
elif page == "Map View":
    map_view()
elif page == "AI Summary":
    show_summary()
