import streamlit as st

# ✅ Define allowed usernames and passwords
USER_CREDENTIALS = {
    "admin": "admin123",
    "user1": "user123",
    "cleaner": "clean123"
}

def login_user():
    st.header("🔐 User Login")

    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Login"):
        if username in USER_CREDENTIALS and USER_CREDENTIALS[username] == password:
            st.success(f"✅ Logged in as {username}")
        else:
            st.error("❌ Invalid credentials")
