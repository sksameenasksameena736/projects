import streamlit as st
import folium
from streamlit_folium import st_folium
from geopy.geocoders import Nominatim

def map_view():
    st.header("🗺️ Waste Location Map")

    city = st.selectbox("Select City", ["Hyderabad", "Mumbai", "Delhi"])
    area = st.text_input("Enter Area")

    if st.button("Show Map"):
        location_str = f"{area}, {city}"
        geolocator = Nominatim(user_agent="waste_locator")
        location = geolocator.geocode(location_str)

        if location:
            m = folium.Map(location=[location.latitude, location.longitude], zoom_start=14)
            folium.Marker([location.latitude, location.longitude], popup="Waste Site").add_to(m)
            st_folium(m, width=700)
        else:
            st.error("Location not found.")
