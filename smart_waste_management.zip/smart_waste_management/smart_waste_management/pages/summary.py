import streamlit as st
import requests

def show_summary():
    st.header("🧠 AI Summary and Precautions")

    input_text = st.text_area("Enter waste description for AI summary")

    if st.button("Summarize with HuggingFace"):
        API_URL = "https://api-inference.huggingface.co/models/facebook/bart-large-cnn"
        headers = {"Authorization": f"Bearer YOUR_HUGGINGFACE_API_KEY"}

        def query(payload):
            response = requests.post(API_URL, headers=headers, json=payload)
            return response.json()

        output = query({"inputs": input_text})

        try:
            summary = output[0]["summary_text"]
            st.success("📝 AI Summary:")
            st.write(summary)
        except:
            st.error("API Error or no summary available.")
