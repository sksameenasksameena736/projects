import streamlit as st
from PIL import Image
import os

def upload_and_predict():
    st.header("📸 Upload Waste Image for Detection")

    uploaded_file = st.file_uploader("Upload a waste image", type=["jpg", "png", "jpeg"])
    
    if uploaded_file:
        image = Image.open(uploaded_file)
        save_path = os.path.join("data/uploads", uploaded_file.name)
        image.save(save_path)

        st.image(image, caption="Uploaded Waste Image", use_column_width=True)
        
        st.success("✅ Image captured and saved.")
        st.info("🤖 Model Prediction Placeholder: 'Mixed Waste Detected'")
